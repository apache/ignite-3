package org.my.job.compute.unit;

import java.util.concurrent.Callable;

public class UnitJob implements Callable<String> {
    @Override
    public String call() throws Exception {
        return "Hello world!";
    }
}
