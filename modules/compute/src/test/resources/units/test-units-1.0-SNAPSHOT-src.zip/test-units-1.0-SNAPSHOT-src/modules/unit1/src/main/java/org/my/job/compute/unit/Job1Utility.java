package org.my.job.compute.unit;

public class Job1Utility {
}
