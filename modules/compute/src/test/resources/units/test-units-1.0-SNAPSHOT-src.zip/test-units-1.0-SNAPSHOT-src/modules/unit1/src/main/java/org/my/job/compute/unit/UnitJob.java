package org.my.job.compute.unit;

import java.util.concurrent.Callable;

public class UnitJob implements Callable<Integer> {
    @Override
    public Integer call() throws Exception {
        return 1;
    }
}
