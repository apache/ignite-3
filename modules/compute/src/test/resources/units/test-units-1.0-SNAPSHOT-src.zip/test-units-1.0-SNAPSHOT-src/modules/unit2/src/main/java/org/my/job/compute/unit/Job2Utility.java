package org.my.job.compute.unit;

public class Job2Utility {
}
